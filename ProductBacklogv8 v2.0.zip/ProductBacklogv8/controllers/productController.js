var bodyParser=require('body-parser');

var data=[{item:'get milk'},{item:'walk the dog'}, {item:'learn NodeJS'}];
var urlencodedParser=bodyParser.urlencoded({extended:false});

module.exports=function(app){
  
    app.get('/backlog',function(req,resp){
         resp.render('backlog',{list:data});
    });

    app.post('/backlog',urlencodedParser,function(req,resp){
         data.push(req.body);
         resp.render('backlog',{list:data});
    });
};