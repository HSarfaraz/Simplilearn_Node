// Read data from the stream 
// Break the data into chucks

var fs = require('fs');

var myReadStream = fs.createReadStream(__dirname+'/readme01.txt');
myReadStream.on('data',function(chunk){
    console.log('New chunk Recived');
    console.log(chunk);
});