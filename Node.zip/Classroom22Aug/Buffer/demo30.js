// Write data to the stream 
// Break the data into chucks

var fs = require('fs');

var myReadStream = fs.createReadStream(__dirname+'/readme01.txt','utf-8');// utf: tells system to use utf type
var myWriteStream = fs.createWriteStream(__dirname+'/writeme02.txt');

// myReadStream.on('data',function(chunk){
//     console.log('New chunk Recived');
//     myWriteStream.write(chunk);
// });

myReadStream.pipe(myWriteStream);