//Creating pur own server
var http= require('http');
var fs = require('fs');

var server = http.createServer(function(req, resp){
    resp.writeHead(200,{'Content-Type':'text/plain'});
    var myReadStream = fs.createReadStream(__dirname+'/readme01.txt','utf-8');
    myReadStream.pipe(resp);
});
// //3. Setup the channel and port
server.listen(9000,'127.0.0.1');

// //4.Fire up the server
console.log('server listening');

