// Updated code of demo26.js

//request: to send https request the server
//npm install request

const request = require('request');
const url="https://api.nasa.gov/DONKI/FLR?startDate=2016-01-01&endData=2016-01-30&api_key=DEMO_KEY"; //Url to live REST API on the web

//Call the REST api, get data, error, complete notification
request(url,{json:true},(err,res,body)=>{
    //Print the data retrived from the live REST API hosted on the web
    console.log(body[0].beginTime);
    console.log(body[1].beginTime);
});