const fs = require('fs');
const os = require('os');

var user = os.userInfo();

fs.appendFile('readme01.txt',`Hello ${user.username}!`, function(){});


// // 1
// const fs = require('fs');
// const fs = require('fs');
// const fs = require('fs');
// const fs = require('fs');
// const fs = require('fs');

// const os = require('os');
// const os = require('os');
// const os = require('os');
// const os = require('os');
// const os = require('os');

// var user = os.userInfo();
// var user = os.userInfo();
// var user = os.userInfo();
// var user = os.userInfo();
// var user = os.userInfo();

// fs.appendFile('readme01.txt',`Hello ${user.username}`, function(){})