//1st way of writing Promise

var promise = new Promise(function(resolve, reject){
    const a=10;
    const b=10;

    if(a==b){
        resolve();
    }
    else{
        reject();
    }
}).then(function(){
        console.log('The numbers are equal');
    }).catch(function(){
        console.log('error');
    })