//Creating our own server like Tomcat, IIS as per our requirement
 var http= require('http');

var server = http.createServer(function(req, resp){
    resp.writeHead(200,{'Content-Type':'text/plain'});
    resp.end('Hello world n');
});
// //3. Setup the channel and port
server.listen(9000,'127.0.0.1');

// //4.Fire up the server
console.log('server listening');

//var http= require('http');
// var server=http.createServer(function(req,resp){
//     resp.writeHead(200,{'Content-Type':'text/plain'});
//     resp.end('Hello World');
// });
// server.listen(3000,'127.0.0.1');
// console.log('server listening !');

//to run http://localhost:9000/