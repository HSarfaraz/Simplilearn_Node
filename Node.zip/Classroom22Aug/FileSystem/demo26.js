// How to access the json data 

//request: to send https request the server
//npm install request

const request = require('request');
const url="https://api.nasa.gov/planetary/apod?api_key=DEMO_KEY"; //Url to live REST API on the web

//Call the REST api, get data, error, complete notification
request(url,{json:true},(err,res,body)=>{
    
    if(err){return console.log('Server error');}
    else if(res.body.err){return console.log('Invalid url');}
    else if(res.body.beginTime==0){return console.log('undefiined parameter');}
    else{
        //Print the data retrived from the live REST API hosted on the web
        console.log(body.url);
        console.log(body.explanation);
    }
});