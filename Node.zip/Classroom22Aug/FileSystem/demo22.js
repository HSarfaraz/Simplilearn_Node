// Creating or deleting the folders

var fs = require('fs');
//fs.mkdirSync('stuff'); //Create the folder

fs.rmdirSync('stuff');
