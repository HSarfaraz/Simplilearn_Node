var fs = require('fs');

var readme = fs.readFile('readme01.txt','utf-8', function(err, data){
    fs.writeFile('writeme01.txt', data, function(){});
});