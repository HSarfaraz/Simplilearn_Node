var data=[
    {ittem:'get milk'},
    {ittem:'Walk the dog'},
    {ittem:'Learn nodejs'},
]

module.exports=function(app){
  
    app.get('/backlog',function(req,resp){
         resp.render('backlog');
    });
};