var express = require('express');
var productController = require('./controllers/productController');
var app = express();
app.set('view engine','ejs');

app.use(express.static('./public'));

productController(app);

app.listen(5000);
console.log('Server is listening on 5000');