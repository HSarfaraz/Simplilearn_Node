import express from 'express';

const MongoClient = require('mongodb').MongoClient;
import bodyParser from 'body-parser';
const port = 8900;
const app = express();

let db;
const mongourl ='mongodb//127.0.0.1.27017/';
const col_name='userlist';

app.use(express.static(__dirname+'/public'));
app.use(bodyParser.urlencoded({extended:true}));
app.use(bodyParser.json());
app.set('view engine','ejs');
app.set('views','/views');


app.get('/',(req,resp)=>{
    db.collection(col_name).find().toArray((err,result)=>{
        if(err) throw err;
        resp.render('index.ejs',{data:result});
    });
});
app.get('/addData',(req,resp)=>{
    db.collection(col_name).insert(req.body,(err,result)=>{
        if(err) throw err;
        resp.render('data inserted');
    });
});
app.get('/delete_user',(req,resp)=>{
    db.collection(col_name).findOneAndDelete({"name":req.body.name},(err, result)=>{
        if(err) throw err;
        resp.send(result);
    });
    resp.redirect('/');
});
app.get('/find_by_name',(req,resp)=>{
    let name = req.body.name;
    db.collection(col_name).find({name:name}),toArray((err, result)=>{
        if(err) throw err;
        resp.send(result);
    });
});

app.put('/update_user',(req,resp)=>{
    db.collection(col_name).findOneAndUpdate({"name":req.body.name},{
        $set:{
            name:req.body.name,
            email:req.body.email,
            phone:req.body.phone,
        }
    },(err, result)=>{
            if(err) throw err.send(err);
            resp.send(result);
    });
});

app.put('/adduser',(req,resp)=>{
    resp.render('admin');
});

MongoClient.connect(mongourl,{useNewUrlParser:true, useUnifiedTopology: true},(err,client)=>{
    if(err) throw err;
    db = clinet.db('sept dashboard');
    app.listen(port,()=>{
        console.log('server is running');
    })
});