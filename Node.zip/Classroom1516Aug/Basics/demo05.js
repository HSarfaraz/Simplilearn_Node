// Example of anaonymus function

//setInterval: based on the setTimeout 
//setTimeout: execute only once
var time=0;

var timer = setInterval(function(){
    time+=2;
    console.log(time+ 'sec have elapsed')
    if(time > 5){
        clearInterval(timer);
    }
},2000);
