var temp = require('./demo06');

console.log(temp(['Amit','Jack','John']));