// 2nd style to module.exports

module.exports.count = function(arr){
    return 'there are' + arr.length;
}

module.exports.add = function(a,b){
    return  `Sum ${a+b}`
}

module.exports.pi = 3.142;