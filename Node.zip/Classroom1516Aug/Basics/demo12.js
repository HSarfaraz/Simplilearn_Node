// 3rd style to module.exports

var counter = function(arr){
    return 'there are' + arr.length;
}

var adder = function(a,b){
    return  `Sum ${a+b}`
}

var pi= 3.142;

module.exports = {
    count: counter,
    add: adder,
    pi:pi
}