var temp = require('./demo10');

console.log(temp.count(['Amit','Mary','Jack']));

console.log((temp.add(5,6)));

console.log(temp.add(5, temp.pi));