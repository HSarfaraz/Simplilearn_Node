setTimeout(function(){
    console.log('3 sec passed')
},3000);