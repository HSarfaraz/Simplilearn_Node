var events = require('events');
//util:Contain set of utility functions, files
var util = require('util');

//Function by default is an object in Javasscript

var Person = function(name){ //class defination
    this.name = name;  //class attribute
}
util.inherits(Person,events.EventEmitter);

//Create an object
var james = new Person('James'); //Object initialisation
var mary = new Person('Mary');
var mae = new Person('Mae');

// Creating collection of objects into array
var people = [james, mary, mae]; // Create a custom object collection

// using foreach to iterate through array
// iterate and picking up 1 value at a time
people.forEach(function(person){ // custom event handlers registration
    person.on('speak', function(msg){
        console.log(person.name+' said '+msg);
    });
});

james.emit('speak','Hey Guys'); // fire the custom event
mary.emit('speak','We arre good'); // fire the custom event