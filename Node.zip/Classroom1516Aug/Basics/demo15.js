var temp = require('./demo14');

console.log(temp.count(['Amit','Mary','Jack']));

console.log((temp.add(5,6)));

console.log(temp.add(5, temp.pi));

console.log('Result :', temp.addNote(10,20));