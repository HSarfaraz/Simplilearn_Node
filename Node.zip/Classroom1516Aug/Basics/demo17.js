//Event Handling

var events = require('events'); //Import sys defined module

var myEmitter = new events.EventEmitter(); //Init System defined obj

myEmitter.on('someEvent', function(msg){ //Define the event: What happen when event occur
    console.log(msg);
});

myEmitter.emit('someEvent', 'This is my custom event'); //Raise the event
