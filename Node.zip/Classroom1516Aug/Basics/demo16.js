// Accessing the capture what user is typing
// process.argv read the data from terminal
var command = process.argv[2];

console.log('command', command);

if(command === 'add'){
    console.log('Add a new note');
}
else if(command === 'list'){
    console.log('List all the notes')
}else{
    console.log('Command not recognized');
}

