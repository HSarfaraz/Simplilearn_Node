// 4th style to module.exports

var counter = function(arr){
    return 'there are' + arr.length;
}

var adder = function(a,b){
    return  `Sum ${a+b}`
}

var pi= 3.142;

module.exports = {
    count: counter,
    add: adder,
    pi:pi
}

// old way module.exports.addNote = function(){
module.exports.addNote = () =>{
    console.log('Add note');
    return 'New Note';
}

module.exports.Sub = (a,b) =>{
    return a-b;
}