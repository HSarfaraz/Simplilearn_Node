// 1st style of module exports

var counter = function(arr){
    return 'There are ' + arr.length + 'elemetns in this array'
};

var adder = function(a,b){
    return `The sum of the two nos is ${a+b}`;
}

var pi = 3.14;
module.exports.count = counter;
module.exports.add = adder;
module.exports.pi=pi;