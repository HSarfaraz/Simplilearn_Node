// x = 10;
// var x;
// console.log(x); // Interpreted language, Variable hoisting

// 1. Normal Function
function sayHi(){
    console.log('Hi');
}

sayHi();

// 2. Function passing as argument to another function using anonymus function
function callFunction(fun){
    fun();
}

// Function Expression | Anonymus function: No name function
//Usage of function expression: Pass it anaother function as a parameter
var sayBye = function(){
    console.log('Bye ');
}

//sayBye(10);
callFunction(sayBye);

