var counter = function(arr){
    return 'There are ' + arr.length + 'elemetns in this array'
};
//console.log(counter(['Amit','Mary','John']));

module.exports = counter;