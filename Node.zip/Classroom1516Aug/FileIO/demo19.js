var fs = require('fs');

// Reading the file 
var readme = fs.readFile('readme01.txt', 'utf-8', function(err, data){
    console.log(data);
});

//console.log(readme);

// Write the file 
//fs.writeFileSync('writeme01.txt',readme);

console.log('finished program');