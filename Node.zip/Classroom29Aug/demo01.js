
// Using Ejs


// Working with Express
//Dynamic Route
var express  =require('express');

var app = express();
// Use my engine
app.set('view engine','ejs');

// listen on http methods

app.get('/profile/:name', function(req, resp){
    //send: method in express
    //end: mothod in http
    var data={age:29, job:'developer', hobbies:['reading','travelling','cycling']}
    resp.render('profile',{person:req.params.name, 'data':data});
});

app.listen(3000);