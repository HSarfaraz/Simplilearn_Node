$(document).ready(function(){
   
    $('form').on('submit',function(){
           var item =$('form input');
           var listitem={item: item.val()};

           $.ajax({
               type: 'POST',
               url: '/backlog',
               data: listitem,
               success: function(data){
                   location.reload();
               }

           });
           return false;
    });

    // Delete
    $('li').on('click',function(){
        //this represents the current context
        var item = $(this).text().replace(/ /g,"-");

        $.ajax({
            type:'DELETE',
            url:'/backlog/' + item,
            success: function(data){
                location.reload();
            }
        });
    })

});