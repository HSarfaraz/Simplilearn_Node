var express = require('express');
var productController = require('./controllers/productController');
var app=express();

// Need to set the view engine
app.set('veiw engine','ejs');

app.use(express.static('./public'));

productController(app);

app.listen(7000);
console.log('Server listening on 7000')