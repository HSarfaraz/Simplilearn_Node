var http= require('http');
var fs= require('fs');

var server = http.createServer(function(req, resp){
    //application/json: We need the output in json format
    resp.writeHead(200,{'Content-Type':'application/json'});
    var myObj = {
        name:'Sarfaraz',
        job:'Developer',
        age:34
    };
    //Convert json into string
    resp.end(JSON.stringify(myObj));
});

server.listen(9000,'127.0.0.1');
console.log('server is running');