

// Working with Express
//Dynamic Route
var express  =require('express');

var app = express();
// listen on http methods
app.get('/', function(req, resp){
    //send: method in express
    //end: mothod in http
    resp.send('This is express js');
});

app.get('/contact',function(req, resp){
    resp.send('This is the contact Page');
});

app.get('/profile/:id',function(req, resp){
    resp.send('You requested :'+ req.params.id);
});

app.get('/profile/:id/:name',function(req, resp){
    resp.send('You requested :'+ req.params.id+" : "+req.params.name);
});

app.listen(3000);