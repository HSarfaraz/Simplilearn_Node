
// Working with Express
//Static Route
var express  =require('express');

var app = express();
// listen on http methods from express
app.get('/', function(req, resp){
    //send: method in express
    //end: mothod in http
    resp.send('This is express js');
});

app.get('/contact',function(req, resp){
    resp.send('This is the contact Page');
})

app.listen(3000);