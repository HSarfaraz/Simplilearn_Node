var http= require('http');
var fs= require('fs');

var server = http.createServer(function(req, resp){
    //text/plain: We need the output in plain format
    resp.writeHead(200,{'Content-Type':'text/plain'});
    
    resp.end('This is sample Index Page');
});

server.listen(9000,'127.0.0.1');
console.log('server is running');