var chai = require('chai');
var expect = chai.expect;

chai.should();

function returnName(name){
    return name;
}
function AddNumToSelf(num){
    return num+num;
}

function IsEven(num){ return (num % 2 === 0);}

describe('Return Name Functionality', function(){
    it('Return the name passed to it', function(){
        returnName('Amit').should.equal('Amit');
    });
});

describe('Match Operations', function(){
    it('Return the name passed to it', function(){
        AddNumToSelf(5).should.equal(10);
    });
    it('Validate even nos', function(){
        IsEven(24).should.equal(true);
    });
});