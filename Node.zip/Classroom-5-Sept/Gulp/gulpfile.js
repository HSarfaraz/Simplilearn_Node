 var gulp  = require('gulp');

var uglify = require('gulp-uglify');
const { doesNotMatch } = require('assert');

gulp.task('scripts',function(done){
    gulp.src('src/*.js').pipe(uglify()).pipe(gulp.dest('dist'));
    done();
});

// to see the output: gulp scripts