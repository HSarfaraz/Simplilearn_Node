// second.js

function secondFunction(){
    return 20;
}