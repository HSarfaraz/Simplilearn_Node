// first.js

function firstFunction(){
    return 10;
}