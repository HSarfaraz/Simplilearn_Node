module.exports = function(grunt){
    // grunt.registerTask('task1',function(){
    //     console.log('Task 1 executed');
    // });

    // grunt.registerTask('task2',function(){
    //     console.log('Task 2 executed');
    // });

    grunt.initConfig({
        concat: {
            dist:{
                src:['js/one.js','js/two.js'],
                dest:'build/js/scripts.js',
            },
            css:{
                src:['css/one.css','css/two.css'],
                dest:'build/css/styles.css'
            }
        },
        watch:{
            jshint:{
                files:['js/**/*.js'],
                tasks:['concat:js']
            },
            css:{
                files:['css/**/*.css'],
                tasks:['concat:css']
            }
        }
    });

    grunt.loadNpmTasks('grunt-contrib-concat');
    grunt.loadNpmTasks('grunt-contrib-watch');
    grunt.registerTask('default',['concat', 'watch']);

    //grunt.registerTask('bothtask',['task1', 'task2']);
    //grunt.registerTask('default',['task1', 'task2']);
}